<html DOCTYPE!>
<html>

<head>
<link rel="stylesheet" type="text/css" href="home.css"> <!--for external styling-->
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <h2>About Us</h2>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>

</header>
<body>

<center>
<p id="aboutus-p">
Frequently Asked Questions...
</p>
</center> 

<br>
<details open>
  <summary>About Us</summary>
  <div class="faq__content">
  <h2> Attenion Realist Gamers </h2>
    <p>Our team have wanted to intoduce a realistic gaming review platform , for all gamers and those who want to know about a game which fits their satisfaction
	<br>
	Founded from 2020 , our small team have been inspired by the diverise scene of gamers.... 
	</p>
  </div>
</details>

<details>
  <summary>FAQ 2</summary>
  <div class="faq__content">
    <p>Answer 2</p>
  </div>
</details>

<details>
  <summary>FAQ 3</summary>
  <div class="faq__content">
    <p>Answer 3</p>
  </div>
</details>

<details>
  <summary>FAQ 4</summary>
  <div class="faq__content">
    <p>Answer 4</p>
  </div>
</details>

<details>
  <summary>FAQ 5</summary>
  <div class="faq__content">
    <p>Answer 5</p>
  </div>
</details>
<details>
  <summary>FAQ 6</summary>
  <div class="faq__content">
    <p>Answer 6</p>
  </div>
</details>
</div>

<!-- CREDITS --> 
<div class="footer">
  <p>Footer</p>
  <p> type here </p>
</div>

</body>
</html>
