<html>
<head>
	<title><?php echo $username; ?>'s Profile</title>
</head>

<body>
<?php 
//check for form submission 

if (isset($_GET['username'])){
	$username = $_GET['username'];
	mysqli_connect("localhost","root","") or die ("could not connect to the server");
	mysql_select_db("users") or die ("that database could not be found!");
	$userquery = musql_query("SELECT * from users WHERE username='username'") or die ("The query could not be exectured, please try again later");
	if (mysql_num_rows($userquery) !=1) {
		die ("That username can not be found, make sure you typed the username correctly!");
	}
	while($row = mysql_fetch_array($userquery, MYSQL_ASSOC)){
		$firstname = $row['firstname'];
		$lastname = $row['lastname'];
		$email = $row['email'];
		$dbusername = $row['username'];
		$activated = $row['activated'];
		$access = $row['access'];
	}
	if ($username != $dbusername) {
		die ("there has been a fatal error. try again");
	}
	
	if ($activated == 0){
			$active == "The account has not been activated yet.";
	} else {
		$active == "the account has been activated.";
	}
	//see what level of access the user has
	if ($access == 0) {
			$admin = "this user is not an admin";
	} else {
		$admin = "this user is an admin";
	}
		
?>
<h2><?php echo $username; ?>'s profile</h2><br />
<table> 
	<tr><td>First Name:</td><td><?php echo $firstname; ?></td></tr>
	<tr><td>Last Name:</td><td><?php echo $lastname; ?></td></tr>
	<tr><td>email:</td><td><?php echo $email; ?></td></tr>
	<tr><td>Username :</td><td><?php echo $username; ?></td></tr>
	<tr><td>Activated:</td><td><?php echo $active; ?></td></tr>
	<tr><td>access:</td><td><?php echo $admin; ?></td></tr>
</table>

<?php
}else die ("you will need to specify the username");
?>
</body>
</html>