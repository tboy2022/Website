<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GENRES-->
<!--THERE WILL BE 6 VERSIONS OF THIS PAGE , ETC THIS COULD BE THE ACTION GAMES LIST-->

<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <h2>Action</h2> <!--ADD GENRE NAME-->

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>

<body>
<br>
<div class="game-container">

  <!--THIS IS WHERE YOU ADD THE GAMES -->
  <div class="grid-game" > 
  <a href = "/action/dying-light-2.php"> <!--THIS IS WHERE YOU ADD THE GAME LINK -->
  <h2 >Dying Light 2 Stay Human</h2>
  <h3>Rating: 3.5 / 5 </h3>
  <h3>Age: 18 </h3>
  <h3>Year of Release: 2022 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div> <!--SHORT INTRO -->
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/shadow-warrior-3.php">
  <h2>Shadow Warrior 3</h2>
  <h3>Rating: 3.5 / 5 </h3>
  <h3>Age: 18 </h3>
  <h3>Year of Release: 2022 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/the-king-of-fighters-xv.php">
  <h2>the King of Fighters XV</h2>
  <h3>Rating: 4.5 / 5 </h3>
  <h3>Age: 13 </h3>
  <h3>Year of Release: 2022 </h3>
  </a>
  <div class="game-game">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/breakout-recharged.php">
  <h2>Breakout: Recharged</h2>
  <h3>Rating: 3 / 5 </h3>
  <h3>Age: 3 </h3>
  <h3>Year of Release: 2022 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/gamedec.php">
  <h2>Gamedec</h2>
  <h3>Rating: 4 / 5 </h3>
  <h3>Age: 18 </h3>
  <h3>Year of Release: 2021 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/hades.php">
  <h2>Hades</h2>
  <h3>Rating: 4.5 / 5 </h3>
  <h3>Age: 12 </h3>
  <h3>Year of Release: 2018 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/psyconauts-2.php">
  <h2>Psychonauts 2</h2>
  <h3>Rating: 4.5 / 5 </h3>
  <h3>Age: 7 </h3>
  <h3>Year of Release: 2021 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/it-takes-two.php">
  <h2>It Takes Two</h2>
  <h3>Rating: 5 / 5 </h3>
  <h3>Age: 12 </h3>
  <h3>Year of Release: 2021 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/human-fall-flat.php">
  <h2>Human: Fall Flat</h2>
  <h3>Rating: 4 / 5 </h3>
  <h3>Age: 3 </h3>
  <h3>Year of Release: 2016 </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  </div>

<!-- CREDITS --> 
<div class="footer">
  <p>Footer</p>
  <p> type here </p>
</div>

<br>

</body>
</html>