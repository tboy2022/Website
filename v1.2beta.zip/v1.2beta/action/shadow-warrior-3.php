<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <title>Shadow Warrior 3 </title>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Shadow Warrior 3  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Action </h4><br>
  <h4>Release: 2022 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 18 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  Shadow Warrior is the latest game released in the Shadow Warrior series which is developed by Flying Wild Hog and released by Devolver Digital. While, the exploration of this game isn't the best and little rough, this is undoubtably an incredibly fun game to play at the combat side with the quick nature of this game never achieving mediocrity and always challenging and amusing.
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="img_girl.jpg" alt="Game Name here">
  </div>
  
</div>

<div class="opinion">
<p>
The character of Lo Wang is back in this sequel but previous event not leading to a positive outcome in his life. The arc and villain of this game is an ancient dragon that brings terror to the world and each attempt to kill it has fouled. He is weak against the dragon therefore has to create an alliance with his former nemesis Orochi Zilla in killing and beating the ancient dragon as generic weapons will not slay it. Both of them go on a journey to search magical artifacts that are put around the land in the quest to create a powerful weapon to kill the dragon. The issue they face is hordes of yoke are around the land and it is down to Lo Wang to kill his way through them.
</p>
<br>
<p>
The game has some light RPG elements with the player finding orbs that are spent in improving the character through his abilities and weapons but works as an old-school 1st person shooter as a base in actuality. Most of the combat within this game is set in small combat areas where Lo is trapped until he has killed his enemies. The game starts with a katana and revolver which is used to destroy weak enemies while as the enemies become badder grenade launchers and twin uzis are used. With badder enemies including huge katana-wielding yokai that can block gunfire or floating helmets whose weak point is on the back of their head. 
</p>
<br>
<p>
There is a lot to like about SW3, to play the game it does feel satisfying with the game feeling consistent visually, it also is brilliant to look and play visually which is a major plus as an aesthetically pleasing game taking gaming experience to another level.  The biggest like about the game and playing it is how excellent the combat feels on it which clearly engages you as a player.
</p>
<br>
<p>
 
Although, not everything about the game is great and smooth-sailing, the story’s writing isn't Shakespearian with it feeling quite cheesy at times, the 3rd act of the game also can feel quite boring and the whole thing tends to feel forced as a cash-grab. This game also isn't the best game to navigate neither unless you are a heavy gamer which can isolate the average Joe. 
</p>
<br>
<p>

</p>
<br>
</div>


<!-- CREDITS --> 
<div class="footer">
  <p>Footer</p>
  <p> type here </p>
</div>


</body>
</html>