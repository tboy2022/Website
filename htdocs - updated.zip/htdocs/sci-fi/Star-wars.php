<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Star Wars Jedi: Fallen Order </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: </h4><br>
  <h4>Release: </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star"></span>
</h4><br> 

  <h4>Age: 16 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  This game in Star Wars gaming franchise which feels separate from the films that created them is an interesting play which for once is a game in the franchise to nails how Stars Wars should feel not just look.  
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/starwars.png" alt="Star Wars Jedi: Fallen Ordere">
  </div>
  
</div>

<div class="opinion">
  <p>The key to this game’s story is friendship with it being core in both gameplay and storyline. The friendship arc of this game is between Cal Kestis who is a Jedi padawan that is hiding after the Jedi Purge that occurred Revenge of the Sith and BD-1 who is droid is given a secret task by the Jedi Master that owned it. After Cal and BD-1 meet, they become inseparable and cooperate well to solve puzzles in forgotten ruins, explore alien environments and get revenge on the Empire. </p>
  <p>Both work in the game to complete a scavenger hunt that was made by BD's last companion, Master Cordova. Before he disappeared, Cordova hid a list of Force-sensitive children throughout the galaxy that could be used to bring back the ruined Jedi Order and challenge the Empire. Clues were left on how to get back the list hidden in BD, meaning Cal and the droid need to explore multiple worlds after Cordova did to free up BD's encrypted memories. </p>
  <p>This game can be very tough and both BD’s support and possible upgrades are needed in this game to go through. Enemies within’ this game are very powerful and hard to out-power. Both the player and villain have a stamina meter to support and control with it telling you how much blows you can take/give before making yourself or them too weak while fighting them to pass through. This games also loves to give the player several enemies to fight at once.  </p>
  <p>There is a lot to love with this game such as how the difficulty can give you the a realistic gaming experience of feeling like a Jedi while being aware of the difficulty. Characters within’ this game is another powerful aspect of this game with it helping a player to experience elements of the franchise. Combat is also spot on in this game with it not being a walk in the park for players and making the player to be self-aware and to think. Visually this game is brilliant with a high frame rate, picturesque to play in and giving a responsive nature.  </p>
  <p>Although, this game is not perfect with a few bad points with the biggest one being how the whole story starts too slow and makes it bland with it taking time to improve. Battles within this game can be annoying was well when checkpoints to go on through being very far at times. The only down point in actual playing quality of this game is the navigation and how playing it can be unnecessarily complex on the controller. </p>
  <p>If you have ever thought how exactly it would be to be a Jedi and want to experience it, this is truly the perfect game for it with it being very engaging and realism being key here.</p>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>