<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GENRES-->
<!--THERE WILL BE 6 VERSIONS OF THIS PAGE , ETC THIS COULD BE THE ACTION GAMES LIST-->

<head>
<link rel="stylesheet" type="text/css" href="home.css"> <!--for external styling-->
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <h2>Sci-Fi</h2> <!--ADD GENRE NAME-->

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>

<body>
<br>
<div class="game-container">

  <!--THIS IS WHERE YOU ADD THE GAMES -->
  <div class="grid-game" > 
  <a href = "gamereview_template.php"> <!--THIS IS WHERE YOU ADD THE GAME LINK -->
  <h2 >Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div> <!--SHORT INTRO -->
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-game">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "gamereview_template.php">
  <h2>Game title</h2>
  <h3>Rating: x / 5 </h3>
  <h3>Age: x </h3>
  </a>
  <div class="game-desc">Add a description of the image here</div>
  </div>
  
  </div>

<!-- CREDITS --> 
<div class="footer">
  <p>Footer</p>
  <p> type here </p>
</div>

<br>

</body>
</html>