<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Psychonauts 2  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sci-Fi</h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 7 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  This long-awaited sequel to this cartoon and amusing game filled with laughter, solid story-lining and charming characters introduced in 2005 is back and better than ever with it not being just a sequel but a classic in its own right. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/psychonauts2.jfif" alt="Psychonauts 2">
  </div>
  
</div>

<div class="opinion">
<P>This game is set just mere days after the first game and only moments after the spin-off sequels it gathered. Here you play psychic child genius Razputin Aquato and Razputin just saved Truman Zanotto, the leader of the Psychonauts from rogue dental/brain surgeon Dr. Loboto. Your mission within’ this game is to figure out who exactly hired Loboto to kidnap the Psychonaut agents in the first film by going inside his head to discover there is a bigger evil here called Maligula who is a known nemesis of the Psychonauts. Maligula was presumed dead after a war that left one of the best Psychonauts mentally scarred and damaged which leads them to believe there is someone working for the other side within the team and to investigate. You have to go inside the heads of the creators of the Psychonauts dubbed Psychic 6. </P>
<br>
<P>This is a superb game that clearly has been well thought out and is incredibly detailed, down to small elements such as the past to the characters and their nemesis and everything in-between is brilliant. This is a really expressive and creative game which handles some real life issues incredibly well with grace and care such as PTSD, worry and addiction while showing they are human traits and at times touching it in a very light way that doesn’t mock these traits. </P>
<br>
<P>The game is phenomenal with many good targets being hit here. The characters and backgrounds are nice, colourful and vibrant which makes it a pleasure to play and brilliant to look at. Writing and direction of this game is also amazingly good with it cooperating as a game in a very good and non-jarring manor. The main character Raz is also a fierce and accomplished protagonist to play as and most importantly it covers real life issues such as mental health in a humble and kind way without any stigma being thrown. Combat on this game is also 100% top tier with fighting as Raz being energetic and fun with platforming being another excellent area of gameplay. </P>
<br>
<P>The only issue there is with this game is how some fights within the game feel like it occurs to gain experience and power not to finish something on a rewarding note. </P>
<br>
<P>Overall this game is absolutely brilliant and I would recommend for absolutely anyone to play it as it can be a lot of fun for all the family. You shall regret not playing it sooner and I’d argue this is even better than the original which was really hard to achieve! </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>