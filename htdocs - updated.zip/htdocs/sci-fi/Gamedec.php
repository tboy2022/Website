<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Gamedec  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sci-Fi </h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 18 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  Anshar Studios’ new and exciting cyberpunk inspired game has a lot to live up to compared to previous injustice player-controlled games such as Disco Elysium and Fallout. The year of delay of this game has certainly been worth it as this game is a fascinating Sci-Fi experience and universe where the player unusually has to adopt the role of a cyberspace detective who has to investigate and figure out crimes that have occurred in virtual space. A slight downfall of the game is how the extent of how open and configurable it is allowing for too many choices for players to commit which overshadows and lets down the game’s unity, especially at the start of the game which makes keeping immersion much harder than it actually needs to be. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/gamedec.jfif" alt="Gamedec">
  </div>
  
</div>

<div class="opinion">
<P>This game is set in Warsaw City which is a megalopolis that is extending to the airspace and created in the wreck there is in Old Warsaw. The lead character and who the player controls have a job role as a Gamedec which is a detective that is qualified in figuring out where people is and discovering any wrongdoings in virtual space. This game is set in the later era of the 22nd century where humans spend most of their time in several life-like online VR spaces where resources such as health pills and sofas are all virtual in longer sessions in most houses were only for those in poverty it not occurring. The fact that someone can be discreet online for those avatars using it has bought the worst side of people in an era that is already declining fast.  </P>
<br>
<P>The runtime of this game is 15 hours and throughout it, codex entries are found to do a lot of construction and improve their land. There is a lot of private information available for players to find and expose it all through older and alien platforms for time - tv and radio. This game shows a bleak, sad yet maybe realistic future although interesting to research and discover.</P>
<br>
<P>The game has a lot of great elements to it with it being a captivating game about the future where the world is incredibly engaging and gives the player power with them being responsible for choices that make differences and are vital. Image-wise this game definitely works as well with the art of the creators being stunning to both look at and play. Another brilliant factor to this game is just how well it works if you want to replay the game with it not being a bore or chore. The game also excels at bringing many different game genres with different elements of each Adventure, Action, RPG and Sci-Fi and creating a very solid game with it. </P>
<br>
<P>Although, this game has some flaws that ruin its potential of being perfect such as how there are noticeable mistakes in the dialogue throughout the game and how some easter eggs and hints within this game are totally pointless and vague. The audio of this game isn't the best either with music in the background being distracting and having nothing to do with the story. There are definitely bugs within this game as well which can make it very hard to play without issues and time delays.</P>
<br>
<P>This game is mostly solid and is totally a game to play even if not as flawless as similar games. It is an exciting game that challenges players and is playable over and over without the way overused need of having sword, knuckles or guns as potential combats and the need in other games to survive. This is a refreshing change where head is used not a weapon as defense. </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>