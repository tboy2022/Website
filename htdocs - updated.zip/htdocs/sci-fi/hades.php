<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Hades  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sci-Fi</h4><br>
  <h4>Release: 2018 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 12 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  The lead character of this game, Zagreus finds himself in a similar unfortunate position  to a lot people in the world stuck in the world and by an abusive senior figure and try to figure a way out. Zagreus has an advantage to help himself in such an awful situation as he is an immortal god although sadly his abuser is his dad Hades who is even higher up than him as ‘the lord of the Underworld’. Zagreus’ sad misery makes an adventurous game for players to play that even non-‘pro’ games can also admire. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/hades.jpg" alt="Hades">
  </div>
  
</div>

<div class="opinion">
<P>The plot of the game is how the lead character seeks a way to be free after spending his whole life in the Underworld and is driven by fresh news for him learning about his birth mum Persephone who vanished years before. Zagreus gains the support of his adoptive mum Myx, the gods of Olympus who have only become aware of him and other known names in Greek mythology. He escapes through his bedroom window although each time he fails, he is bought back to the hub and needs to strive again to leave. </P>
<br>
<P>Most of the game is spent fighting people within Underworld who are trying to stop him and defeat them to ensure that can move on easily. Anticipation is strong throughout the game with the player never actually being aware what will occur next. Players walk through combat rooms in this game to move on forwards and succeed with there always being 1-3 doorways to walk through with some boot earnt with each door. </P>
<br>
<P>The game has much a player could and will love such as how the game contains quick action throughout, responsive controls that make fighting others quick and effective. It is also unexpected which adds to the glory of the game with something new always around the corner that could be effective. This game looks great as well with a high refresh rate and nice atmospheric colour pallet that looks excellent. This is a brilliant and fresh Action and RPG (Which aren't the lightest games to play) game that anyone and their nan can play with pleasure. </P>
<br>
<P>The only annoyance with this game is how the script can be apparently awful, poor and cringeworthy but the actual game and it’s clear appeal way overweigh this with it still being a good game. </P>
<br>
<P>This is a solid game with almost a perfect score that will attract any kind of player, no one will regret playing it. While their reputation is strong this is by far Supergiant’s best game unarguably which is not easy to accomplish at all. </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>