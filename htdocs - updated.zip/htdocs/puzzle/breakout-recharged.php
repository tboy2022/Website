<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Breakout: Recharged</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Puzzle</h4><br>
  <h4>Release: 2022 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 3 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  This classic game that has been played for decades since its creation in 1976 on a series of different devices such as iPods and Blackberry mobiles as a simple yet effective game to entertain is back and better than ever. The game which as the player controlling a paddle at the bottom of the screen as it moves side to side thanks to player has been modernized for the 21st century while thankfully keeping the original formula and concept. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/breakout.png" alt="Breakout: Recharged">
  </div>
  
</div>

<div class="opinion">
<p>In Breakout: Recharged, there are several ways to play the game such as playing the original simple game while trying to improve your skill and improve the last and best high score. While, a challenge mode has been introduced with challenges involving breaking a specific amount of blocks or surviving for a certain n amount of time etc.</p> <br>
<p>This game introduces a wide arrange of power-ups such as having several balls on the go or blocks that explode once contacted. The main survival mode will introduced them at random times unless disabled. Might seem simple but this game isn't as easy as it seems with losing being a regular occurrence at first unless trained on the game.</p> <br>
<p>This game can be attractive to look as with gameplay being buttery smooth and the clear, crisp yet simple neon style of it looking fun and satisfying. With the game being easy to function and play without feeling like a chore.</p><br>
<p>Despite the backdrop, colour scheme and music being a great selection to appeal to the public, after a while the game and these attributes can become jarring as you are used to seeing and hearing them again and again.</p> <br>
<p>If you enjoy playing the original, you will certainly like this as it keeps the exact same formula just modernized and improved. Contains an attractive colour scheme of mostly purple and blue hues with look great on an OLED screen such as the Nintendo Switch OLED model and has a good soundtrack to work with it as well. This is a great love letter to the original while improving the game majorly with the challenge mode implemented.</p>   <br>

</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>