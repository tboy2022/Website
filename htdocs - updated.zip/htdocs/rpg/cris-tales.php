<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Cris Tales  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: RPG</h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 12 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
This game was developed by both Uncorporated Games and Syck and published at Modus Games Japanese RPG game that fans of it will love. The game’s story lead is a child orphan called Crisbell whose life changes forever once she meets a new cute small frog who has a top hat and steals a rose from her and quickly after, she is a foreseen Time Mage which means she has the ability to see both the past and future at the same time with today. Taking advantage of her new powers, she goes on a mission to protect the world from the evil Time Empress with a team of bizarre companions, the frog and other people who have the same ability.
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/cristales.jpg" alt="Cris Tales">
  </div>
  
</div>

<div class="opinion">
<p>The plot of this game is not always groundbreaking although the storytelling is another question with it always managing the entertain and engage with the player with a good example being times where Crisbell can tweak the future for good but that doesn’t lead to a positive one for everyone. The game has a big emphasis on the moral dilemma with the player being tested on what’s right and wrong with a perfect example being how there is a possibility being saving storefronts from rot being possible at the start but only one is able to gain this.   </p>
<br>
<p>The game also has a big puzzle element to it as well with you using time travelling powers to clear paths inside small dungeons once you move through them. The way that the powers get used in the game are expected and a bit boring but there are enough creative obstacles and puzzles in Cris Tales that things do not become a big bore, especially at the running time of the game is 30ish hours. </p>
<br>
<p>This game is certainly a solid JRPG game with a lot to love inside such as a game that challenges the player and the way life works for the better, the story of the game itself is quite heartening with the change to make a change and do good is very apparent especially for others. The Puzzle-like combat of the game is also brilliant with it adding another dimension to the game and pushing the player so that the game isn’t dull and simple. This is visually very pleasing as well with a brilliant and vibrant art style of the game making it fun to play.  </p>
<br>
<p>Although, the game is not all rose-coloured with some annoyances coming up within the game. A big once visually is the low refresh rate making combat a lot harder and less enjoyable to play as moves come to a while after. The fact that you do not have enough time to do certain tasks is another very annoying aspect of the game and how weird it is that there are a lot of bizarre unrelated cameos that go face to face with Crisbell occurring in the game. </p>
<br>
<p>Overall, this game is a really good RPG and puzzle game that adds in some unexpected but effective gameplay ideas and a good artistic look. This game does just barely enough to be an entertaining game that every RPG player needs.  </p>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>