<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Nova-111  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: RPG</h4><br>
  <h4>Release: 2015 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 3 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
   In this game created by developer Funktronic Labs is both a dungeon crawler combined with a puzzle game which is a combination of live moments and decision-based gameplay. This game does not outstay its welcome either with the fact that it does not take long to finish although might take a bit longer to discover every secret. The short running time that flies by can also affect the game as it cannot show  its full potential. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/nova_girl.jfif" alt="Nova-111">
  </div>
  
</div>

<div class="opinion">
<P>The player here operates an orange vessel called Dr Science that is abandoned and stuck after a botched scientific experiment. Other people in the team have been scattered at all of time and space where the player needs to discover what caused this to occur and get back to the scientists. After rescuing other members, they only say 1-2 lines of dialogue then fade into the background. High scores here are monitored by how quickly someone can achieve a level but also how many turns, hidden secrets and people rescued come into it. While Dr Science can speak it is bare to non-funny pun-filled ‘comedy’ which cringes a player up and dialogue of guides. </P>
<br>
<P>The game’s navigation is split into elements with 3 planets that do change backgrounds and add new features to the game with them all separated again to 6 unique zones that can be used by an overworld map.</P>
<br>
<P>This game is a mostly very strong game with the concept and execution being both clever and entertaining. It is also a brilliant game to play on the go because it isn't demanding to play at all. Visual aspects of the game are positive with being there accurate to the mood of the story at the time with each planet looking unique but in an appropriate way, the same with the aliens who look like they are a part of that planet but again slightly different where you actually notice it.</P>
<br>
<P>A bad point of this game to some extent is how annoying how short it is as it does ruin the games’ potential with much more that could be explored here. The game can also be quite buggy which is a nuisance, the low framerate also doesn’t not help as it causes a lag which ruins the experience and make completing them feel like a chore. </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>