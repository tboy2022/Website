<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Everhood  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: RPG</h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 7 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
The game Everhood has a lot of aspects within that brill back heavy nostalgia for any gamer with it also seeming like the perfect candidate to be a critically acclaimed Indie game with a lot going for it such as unique and cool characters, old-school visuals and graphics, very catchy and amusing music throughout and a non-conventional battle system. This game is clearly kind of inspired by old iconic games but this is a red herring with a gamer not being as familiar as they feel at the start. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="everhood.jpg" alt="Everhood">
  </div>
  
</div>

<div class="opinion">
<P>In this game, players used a wooden puppet who is called Red who wakes to discover themselves in a random forest with it apparent immediately that their arm has been stolen by a blue gnome. In this game, red follows the thief and start the game and journey which has unexpected twists at every moment ahead. Some games here are better going into with no idea what to expect but after a while, it is obvious that whatever is happening is darker than it seems. In the game, Red encounters a lot of different characters such as dancing mushrooms that adore playing hide and seek, lampposts that love a chin-wag and a vampire with an awful cold who is called Noseferatchu. Some are there to be friendly and chat but others are there to sabotage him.  </P>
<br>
<P>There is a lot to like about this game such as how creative the game is and how fun but nostalgic the games within it really are. Effects are also a really good factor within this game with effects during the battles adding to the suspense. This is not a hard game to play with effort have been implemented that the player can have a lot of fun with it. Music within the game is also very solid with the best coming last which also elevates the final chapter.  </P>
<br>
<P>There is a lot you might dislike as well, the game isn’t too visually pleasing to look at as it is dated with 16 bit-style graphics that is purely there to bring back a child in gamers. While it is a nice love letter to the past, the refresh rate nor visuals impress much as it cannot. There is also an unbalanced wait with load times while changing areas as well with it occurring quick at times and being a chore to wait at others.  </P>
<br>
<P>This nice and quick (6 hours to complete) game is a very entertaining and effective game to play if you prioritize fun and nostalgia. It is able to break free from potential influences and is totally its own game with this adventure being unsimilar to anything that has happened before. </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>