<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>The Cruel King and the Great Hero</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: RPG </h4><br>
  <h4>Release: 2022 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 7  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
This 15 hour gameplay story is an RPG game based on a basic fairytale with actual gameplay coming after. This whole game is in the style of a kids’ book and clearly shown well. While, this game can become boring and painfully long moments going through actual gameplay and battle system, the final chapter is great when it reaches its last chapter. 
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="cruelking.jfif" alt="The Cruel King and the Great Hero">
  </div>
  
</div>

<div class="opinion">
  <p>
The game is based on a junior woman called Yuu who wants to be a fantastic hero like her father already is, her father is infamous for bringing down the great Demon King and to help her, she has a ruthless Dragon king who she calls as dad which is great assistance in training and support her to achieve this. Each night, he repeats stories about her father that exposes more and more about the Dragon king each time. She tries to help the monsters at Monster Village, helping with issues between the monsters and people while facing her father’s old past. This game’s story is vital to it but gets achieved brilliantly with the story being detailed. 
  <br>
  <p>
There is a battle mode to this game with the options within combat being standard attack, special attack, item, guard, or escape with each character having a stamina point which duties as health and energy points being used each time she uses special attacks. There are 3 different friends that you see with Yuu in this game where the player has the option which one to use. 
  <br>
  <p>
There are a lot of good points to this game such as sounds within this game are brilliant such as a satisfying sound to the menu and text boxes that have a delightful page-turning sound, the game visually is also brilliant which rich colours and details areas. The gameplay is also very smooth with zero lag occurring while fighting. 
 <br>
 <p>
Bad points to this game include how this game can become a bit bland at times and how English users might become annoyed with only a Japanese option being available to play despite English subtitles. Playing in combat isn’t ideal neither with controls at times being unnecessarily awkward. 
  <br>
  <P>
Overall, this game is a brilliant and kind story to play that is detailed and is delivered great through a strong story, visual and sound design with more positives throughout the game to negatives. 
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>