<html DOCTYPE!>
<html>

<head>
<link rel="stylesheet" type="text/css" href="home.css"> <!--for external styling-->
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <h2>Trending Games</h2>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<center>
<p id="trend_high-p">Introduction to Trending Page</p>
</center>

<br>

<center>
<p> These are currently the most trending video game reviews we have at Realist Games:</p>
</center>
<br>
<div class="game-container">

  
  <div class="grid-game"> 
  <a href = "/action/dying-light-2.php">
  <h2>Dying Light 2 Stay Human</h2>
  <h3>Rating: 3.5 / 5 </h3>
  <h3>Age: 18 </h3>
  </a>
  <div class="game-desc">Gameplay of Dying Light 2 Stay Human</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/shadow-warrior-3.php">
  <h2>Shadow Warrior 3</h2>
  <h3>Rating: 3.5 / 5 </h3>
  <h3>Age: 18 </h3>
  </a>
  <div class="game-desc">Gameplay of Shadow Warrior 3</div>
  </div>
  
  <div class="grid-game"> 
  <a href = " GAME DIRECTORY">
  <h2>Windjammers 2</h2>
  <h3>Rating: 3.5 / 5 </h3>
  <h3>Age: 3 </h3>
  </a>
  <div class="game-game">Gameplay of Windjammers 2</div>
  </div>
  <div class="grid-game"> 
  <a href = " GAME DIRECTORY">
  <h2>The Cruel King and the Great Hero</h2>
  <h3>Rating: 3.5 / 5 </h3>
  <h3>Age: 7 </h3>
  </a>
  <div class="game-game">Gameplay of The Cruel King and the Great Hero </div>
  </div>
  </div>

<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>

</body>
</html>
