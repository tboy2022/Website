<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Mario Tennis: Ultra Smash</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2015 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 3  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
This latest sports game in the iconic Mario game franchise has a lot to live up to especially when you look at a previous successful sports game in the franchise. Despite the colourful and iconic characters and backgrounds of this game, this game has certainly failed compared to efforts that came before it due to design issues throughout and how limited it feels to previous games with not a lot to do. 
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/mario.jpg" alt="Mario Tennis: Ultra Smash">
  </div>
  
</div>

<div class="opinion">
  <p>
This game is set around a huge tennis competition around Mario, his friends and his foes where you got to beat the competition to become the winner of the tournament and become the biggest alpha of them all. Although, it manages to do it quite poorly with not enough features implemented and bizarre, unneeded and annoying features included which do not improve gameplay in any shape or form.  
  <br>
  <p>
This game is so bare that it even lacks a tutorial mood which means new players have to go in right to it and hope to master their art quickly without any decent guidance, especially at the navigation on the game with controllers is pathetic with accidentally hitting random buttons becoming a regular occurrence and needing to figure working it out on the job which is not helpful as the CPU player of the game is strong which leaves you defeated and humiliated as they are aware of much more techniques than the player and how to implement them.  
  <br>
  <p>
There are a few things to like about this game such as how quickly-paced the game is and that gives a nice nostalgic arcade vibe. The multiplayer action is also flawless for fun competitive gameplay against other local players such as a loved one. How shots of the ball are carefully planned with the mechanics of the game is another strong point to the game.  The game is beautiful and vibrant to look at with zero lag nor bugs making it the perfect experience to look at without any issues. 
 <br>
 <p>
The lack of different game modes and ways to play are things that definitely could be improved upon with this game with it feeling bare and jaded after a while and losing any competitiveness energy that was felt. There is not a lot to strive for with this game neither as only simple unlockables that are accomplished quickly are available here. There is also major gameplay infuriating aspects to gameplay here at times as well, especially without a proper and decent way of learning how to play the game and controls that choose to do whatever it wants to do which ruins any chances of winning with the game going rogue
  <br>
  <P>
This game is just enough to satisfy someone for a few hours despite its annoyances but is only actually worth it if you are planning to play in multiplayer mode otherwise I would not recommend this game to buy. In that case, I would recommend an older game in the franchise as this lacks real features or to play something different in that universe such as Mario Kart. 
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>