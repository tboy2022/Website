<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>AO Tennis</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2018 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 3  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
The game AO Tennis argues that it is ‘the most advanced tennis game ever produced,’ but it’s claim doesn’t really manage expectations. The game isn’t even good compared to the quality of games such as Top Spin that were brought out at the generation of consoles before. This game is shows that it was half-efforted and not creative.  
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/AOtennis.jpg" alt="AO Tennis">
  </div>
  
</div>

<div class="opinion">
  <p>
Although the game has some creative fresh ideas, the ideas are half-baked due to the fact there aren’t any tutorials in the game with a good example being how the right thumbstick to do shots at and serve. Buttons is another downfall of the game with aiming for good shots, making you hold the shot button to power it up by a gauge that moves next to the player with aiming with a reticle in your opponent's corner.  It seems logical but doesn’t work well in person. A lot of the time, you will move to a position to return to the ball, prepare the shots and release it while the opponent a the game has some creative fresh ideas, the ideas are half-baked due to the fact there aren’t any tutorials in the game with a good example being how the right thumbstick to do shots at and serve. Buttons is another downfall of the game with aiming for good shots making you hold the shot button to power it up done by a gauge that moves next to the player with aiming with a reticle in your opponent the game has some creative fresh ideas, the ideas are half-baked due to the fact there aren’t any tutorials in the game with a good example being how the right thumbstick to do shots at and serve. Buttons is another downfall of the game with aiming for good shots, making you hold the shot button to power it up by a gauge that moves next to the player with aiming with a reticle in your opponent's corner.  It seems logical but doesn’t work well in person. A lot of the time, you will move to a position to return to the ball, prepare the shots and release it while the opponent a the game has some creative fresh ideas, the ideas are half-baked due to the fact there aren’t any tutorials in the game with a good example being how the right thumbstick to do shots at and serve. Buttons is another downfall of the game with aiming for good shots making you hold the shot button to power it up done by a gauge that moves next to the player with aiming with a reticle in your opponent's  corner.  It seems logical but doesn’t work well in person. Often, you will move to a position to return to the ball, prepare the shots, and release it while the opponent awaits as the ball bounces by them.  
  <br>
  <p>
The visuals on this game is brilliant with clear shots, good audio and a high framerate all being big pluses on this game and make it really aesthetically pleasing.  
  <br>
  <p>
This game is entertaining enough and if necessary it will be a nice game for someone to play but after a while, it will get a bit boring and people will have enough of the game as it can be a bit frustrating to use with how bad controls are on its controllers. You also cannot practice how good you are at tennis on the game either. The game is very buggy as well with the effort and issues while throwing the ball being a good example. 
  <br>
  <p>
Overall, the concept behind it is great and creative but how undeveloped it is sad really how let down it is however there is hope that a lot more features and bugs can be fixed soon to make it a worthwhile game. 
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>