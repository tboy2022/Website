<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Windjammers 2</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2022 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 3  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
This game based on the game frisbee is undeniably compelling with it combining both sports and anime with a battle element included to it as an extra selling point. This sequel to the almost three-decade-old game is fresh and vibrant to make loyal and new players alike excited to throw the virtual frisbee and show off their chic tricks that were developed.    
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/windjammers.jpg" alt="Windjammers 2">
  </div>
  
</div>

<div class="opinion">
  <p>
The game is simple as again it is only frisbee but multiple methods to make this simplistic game exciting. The player gets an option of a wide area of international characters to play with and gains features like the ability to choose a lot of new defensive and offensive options then combine them to ruin your opponent. This game requires multiple skills to be used such as the mind and body with mind games, fast thinking and genius movement tactics being used to win the battle which contributes to this game bringing a shockingly big appeal for any kind of player.  
  <br>
  <p>
The game feels hot with the new playable characters adding a new lease of life to it and the fact that multiplayer has been added which is the biggest selling point of the game allowing a player to challenge anyone online such as a loved one which makes it even more competitive although there is also a CPU option to play against with it being shockingly ungenerous towards the player which makes the player itself bring more of themselves towards the table. However, the CPU player can leave one annoyed with how smooth that player is just magically appearing at strange places etc.  
  <br>
  <p>
The good of this game is brilliant with major selling points including how multi-player is incredible fun that challenges you and that is quick and not slow but also captivating to play. The new defensive and offensive options bring much intensity to the game compared to the original which is needed and appreciated in today’s age. The whole game and online play also work instantly with zero lag with a high fresh rate helping a helping and a vibrant mood board.   <br>
 <br>
 <p>
Although, the game is not perfect with some issues occurring such as how not a lot has actually changed in this game besides VS play and a basic arcade option to think that it is almost 30. This is also a very difficult and menacing game for inexperienced players to play with a monstrous CPU making any success possibility hard and the lack of development tools for newbies possible. The soundtrack is not great either with the audio in the background not being good taste and a weird selection for the game. 
  <br>
  <P>
I would recommend this game as it can be a great fun that is colourful, testing in a positive way and so competitive especially if you are a lover of frisbee or the iconic original game. I could also recommend it to a beginner although they would need to be prepared to be a challenge and up their game…., especially against the CPU.
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>