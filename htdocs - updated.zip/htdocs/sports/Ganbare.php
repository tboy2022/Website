<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Ganbare! Super Strikers</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2020 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 3  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
To start the review, this game was not a too easy game to implement and play with a lot of technical issues happening straight into Story Mode with a lot of players commonly having to restart the game. While the game does sound interesting being game heavily focused on the genres of RPG, Adventure and Sports and has a nice niche and fresh sound and feel to it. It soon wears thin and the gamer becomes bored quickly. 
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/ganbare.jpg" alt="Ganbare! Super Strikers">
  </div>
  
</div>

<div class="opinion">
  <p>
This game introduces a story mode where the player can customize their own player, team and football team badge. After working through that and choosing whether to follow through with the tutorial or skip ahead, the team can play the 1st of 7 National Cup matches they are going to play and they are followed through with the World Cup matches. If the team wins the game they are able to move on within the tournament with winning allowing one to get up to 3 stars with one always being earnt for winning and the other 2 for going above and beyond in skill and for achievements such as stopping the other teaming from scoring, using special skills in the game etc. These stars are then used to move along to gather better equipment to improve, boost statistics and abilities.  
  <br>
  <p>
There are 2 fields the player needs to be aware of and monitor- both AP and SP. The SP gauge is drained each time a fellow member of the team moves around or does something with that team member becoming exhausted and losing good statistics once empty while the AP gauge is lowered each time a team member uses special abilities such as tackling a member of the other team making you aware it isn’t a good idea to exhaust these moves. This game works very similarly to how a game of football would actually work. 
  <br>
  <p>
This game can a fun one to play for a short while with it feeling like a nice quick game to enjoy where you do not have to think too hard. The high refresh rate is another good factor that is implemented within this game which makes the game and ball kicking run smoothly where the player does not have to miss a beat. The coloration of the game is fun and colour as well which keeps the player positive and engaged compared to how they’d be if it was gloomy. 
  <br>
  <p>
Although, there are enough negatives to this game with a big one being how undercooked it feels despite sounds like a cool and interesting combination, all RPG, Adventure and Sports. This game does not deliver a lot to be improved on to become a solid game. With the standard view of a slanted top-down view not being the best to look at and play in real-time with, members of the team and public blocking the view can make it hard to look at. Stupid stunts within the game ruin its potential as well with unneeded ’features’ such as climate and body height affecting the players’ potential which irks the player and how they feel about the game. 
  <br>
  <P>
This game clearly does not understand the assignment and is incredibly defective which does not make it a good experience or game to play at all. I would avoid this game at all costs as there is not a USP for anyone and obviously isn’t even that good. 
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>