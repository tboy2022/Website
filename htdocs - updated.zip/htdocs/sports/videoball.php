<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Videoball</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2016 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 3  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
This low maintenance yet eccentric game is a big barrel of laughs that will attract any video game fans with the major feeling of childhood and nostalgia occurring  throughout the game that brings a lot of warmth to it in the structure of the game. Everything from the title sequence, to voices to background music to menus, will be pleasing to hear with the whole game from looks, vibe and audio being a massive kick of Deja vu in your head.
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/videoball.jpg" alt="Videoball">
  </div>
  
</div>

<div class="opinion">
  <p>
The concept is simple with a ball being thrown in the middle of the field and 2 teams battling it out to get the best of out their opponent with the need to shoot the ball into their goals. This game is 2D with the ball being a generic circle and the players' colour coordinated in both blue and red showing which team they are on which adds to the simplistic nature of the game with less is more being effective here. 
  <br>
  <p>
Actual gameplay here is inspired mainly by football and the US version of soccer but is a brilliant game to control with only a single button to use which is to shoot with by using a quick tap although using the button in different ways such as longer brings different outcomes such as firing the ball at the speed of light. The game carries its humour on aspects bouncing off each other such as when you hit the blue with your arrow, you will be pushed back and leave you surprised. 
  <br>
  <p>
This game also has an ideal arcade mode if you do not want to play multiplayer with others. It does not become as exciting as playing and hopefully beating your friends while bouncing off their energy but each CPU arrow has its own personalized special tricks up its sleeve with there not being a bore here of playing with a computer for that reason. The CPU can be too stupid at times though with it missing the most simple shots. 
 <br>
 <p>
The great positives of this game include how it is a brilliant multiplayer game to play with enough options to keep you satisfied for hours and keep yourself challenged against others. Another very strong aspect of the game is how it is an entertaining game even with the slightest bit of design which is still fun and vibrant enough. The game also has a sharp attraction for being different in the sports genre of video games. The game is mostly responsive with game controls working brilliantly and efficiently to become incredibly playable. 
  <br>
  <P>
The only negatives are how limited the control options are with only a single option which is tank controls and how the CPU of the game can play up at times with there being some clear bugs affecting gameplay at times.
  <br>
  <p>
I would recommend this game to absolutely anyone with the fun factor in it being 11 and how it could bring a set of family, friends etc. to play a sports game with ease that could contain a lot of laughter without feeling like any type of chore to do at all. 
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>