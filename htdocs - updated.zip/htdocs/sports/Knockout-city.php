<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Knockout City</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star"></span>
</h4><br> 

  <h4> Age: 10  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
  Knockout City is a new intense cooperating game based on the US game dodgeball that includes easy moves and skills to learn and develop with professional and complicated maneuvers, this game can bring this to the table whilst looking like a childhood cartoon series. The game is clear and rewarding to play while bringing the benefits of a PE lesson without downfalls. 
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/knockout-city.jpg" alt="Knockout City">
  </div>
  
</div>

<div class="opinion">
  <p>
The visuals and sound of this game are brilliant with the playlist of songs being fun and encouraging and the characters looking good once you pass the fact it can look like a Bratz toy. The setting and scenery are colourful and vibrant with there being cool abjection and mods being available on this game. There is a unique and dope sound the individual balls make when they make contact with a person. the rule of this game is how a gang of 3 or 4 have to defeat and disable the other team by throwing the dodgeballs that cover the whole map at them. One must be struck twice to be knocked out and the gang to make this occur 10 times win.
  <br>
  <p>
The tactic is the name of the game here with somewhat mind games being the ultimate power to break your potential victim’s defence. The ball can be struck faster or through a slower one to surprise the victim and their timing. throws that curve around are possible as well. Real person techniques appear here as well.
  <br>
  <p>
This game is brilliant with a lot going for it such as how simple yet fun this game is, how colourful and animated the characters and setting are, down to smaller things such as real-life effects like the sound of a ball being thrown. It also thinks out of the box with a ball-less mode being available where you throw other members of a gang to the beat the other. This vibrant game also has a brilliant high-fresh rate which makes it much more realistic and effective. With no bugs being found either this is a silky smooth game to play. 
  <br>
  <p>
There is not much at all to complain about as the game is finessed. The only critic is how simple the concept can be which will most likely make it boring for one after a while
  <br>
  <p>
This is undoubtedly one of the best player vs player games in a while. It is a hot and modern look at the traditional US school game which means it is playable for almost anyone as it is so simple to play and navigate while being competitive! 
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>