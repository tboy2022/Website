<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Skater XL</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2018 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 3  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
This skating game that is purely about skateboarding with no unnecessary gimmicks gets the technically of the sport to the t in ways such as mastering the spot, location and development and progress from past mistakes. This game falls flat compared to legendary skating games when it fails to encourage a player to move forward and practice different skills and tricks on mediocre uninspired levels.   
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/skater-xl.jpg" alt="Skater XL">
  </div>
  
</div>

<div class="opinion">
  <p>
While the trick system of this game is very easy to understand and exciting to be lectured on. The gaming controls don’t cooperate with the game with 1 analogue stick unrealistic and unplayable if you want to play a videogame about skating properly.    
  <br>
  <p>
The limited choice of backgrounds and levels within this game cannot be a positive factor with it being a bit boring with only 5 levels made by the developers themselves and another 3 that are community-based. Settings include a skatepark, a rural neighborhood and a school. While these are spots a skateboarder would use they do not feel creative to use at all. The tutorial of this game is also incredibly bare and unfulfilled which doesn’t mention important details and tricks possible with depth. You learn generic tricks in this game and are left to it. 
  <br>
  <p>
Positives to this game include how it does have some good elements of an unmissable and unique skateboarding game and how the soundtrack to this game is incredibly fitting with a lot of music including being some of the noughties’ most legendary indie rock acts. The replay editor implemented within the game also gives the player a lot of input for their best potential to do cool tricks. Graphic wise the game is fitting and modern with gameplay being buttery smooth which is good as you need to know what happens at that second. 
 <br>
 <p>
Negatives include how boring the levels are and lack thereof which make some design issues of this game even more apparent. The design also fails to give exciting spots for known tricks to be flexed. The incredibly dull and uninformative tutorial combined with appalling menu design makes the game feel lazy and uncompleted. 
  <br>
  <P>
This is not the best game to play if you are a skater at this moment in time with recommendations like the Tony Hawk Series being much better for gameplay and a full-on experience. I would avoid buying or playing this game because of how severely undercooked and thought of it feels. 
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>