<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Skatebird</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Sports </h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4> Age: 12  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
 This game which is Pro Skater and Micro Machines put together is like a mediocre meme bought to life with the concept being petit birds riding a fingerboard on minuscule ramps around different settings such as a workplace and a bedroom. This game tries to be a third-dimensional light skateboarding game with the result being an adorable and head-turning yet basic, quick and annoying game to play. 
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/skatebird.jpg" alt="Skatebird">
  </div>
  
</div>

<div class="opinion">
  <p>
This is a very random game to come up with and can feel uninspired. Again, Pro Skater is the main inspiration here and the concept they came up with which was to allow whoever was playing to wander around the maps looking for certain unimportant and light tasks. These tasks are thrown all around the map but they are not heavy or essential as a lack of countdown while completing them will show. Unironically, the mood is delivered well with the playlist being full of unforgettable primary bird-related songs. The playlist could be considered the best part here with it being full of calm yet effective songs that even the player aka the birds grooves to.   
  <br>
  <p>
This game does not give the player the task and while going around you will encounter them while not closed away from being seen, it can be agitating to control and complete quickly. Most tasks here are quite simple with the actual time to complete it and gather items also being brilliant for laziness and a lot of resources are around the same place at the game while can make the game bland and you are not challenged at all.  
  <br>
  <p>
This game is brilliant with a lot going for it such as how simple yet fun this game is, how colourful and animated the characters and setting are, down to smaller things such as real-life effects like the sound of a ball being thrown. It also thinks out of the box with a ball-less mode being available where you throw other members of a gang to the beat the other. This vibrant game also has a brilliant high-fresh rate which makes it much more realistic and effective. With no bugs being found either this is a silky smooth game to play. 
  <br>
  <p>
The positive thing about this game is how light it is to play if you do not want to commit too much time or a general player of games. The playlist again also is brilliant, the game is vibrant and fun to look at with all its light colours without gloom. 
  <br>
  <p>
Although there are many bad points to this game such as how basic the game is without a need of being challenged with simple tasks and enough time. It doesn’t help how there are only 5 levels to play on therefore there isn't a lot of gameplay with this game without already completing it with a certain level being beige with a nano rooftop. The entertainment of this game isn't helped with the lack of multiplayer to play with others and simple maps to explore. To look at it can be quite annoying as well with how amateur the camera and controls of the game are with it struggling to showcase progress on-screen without hassle where it shakes and the player gets stuck at a bizarre area of the screen with struggle. 
<br>
<P>
Minus the fact that this game is adorable and with a great music act with it. Skating on this game is outdated, the concept and possibilities are lazy and to view it is a headache. While it can appear amusing, it isn't worth playing unless you really love birds. 
<br> 
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>