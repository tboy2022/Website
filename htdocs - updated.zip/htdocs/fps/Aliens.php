<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Aliens: Fireteam Elite  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: FPS </h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 16 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  This latest Sci-Fi game based on the Alien franchise that centres around a lot of shooting is a great laugh and time when played with a simple and wacky mindset. This game which is inspired by other gaming franchises such as Gears of War which makes it feel a bit unoriginal is saved by small yet effective original elements and the setting of the Alien movies which make it very playful and engaging which is impressive to consider how dialogue in this game can be questionable, the uninspired story and non-player characters who are able to communicate with their mouths closed without any creative excuses to justify why that occurs. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="aliens.jpg" alt="Aliens: Fireteam Elite">
  </div>
  
</div>

<div class="opinion">
<P>The story of this game takes place years after the Alien films. The character played here is appropriate Colonial Marines on a mission to various panic signals. This game could definitely be considered third-person shooter with the player attempting to get the needed targets and striving to clear out places within the game that are full of Xenomorphs. This is a brilliant game to play with loved ones online as you are able to cooperate in a team. 5 different classes to pick from, that all contain personalized qualities such as a technician role. </P>
<br>
<P>The entertainment factor of this game can depend on whether you do play with other humans or the non-player bots that are bleak and none verbal which can making it a relatively boring situation. With other players, it can be a barrel of laughs and amusing time but without, it can seem like a bit of a chore to play and complete. </P>
<br>
<P>The positives for this game include how realistic it feels and how as a player, you do feel like you are playing on an Alien film and the potential fun factor of playing it online. It is also fun that it does not take itself too seriously and is a decent shooter sci-fi game. Visually, the setting again looks authentic and detailed, the game thankfully is easy to navigate on a controller as well which is a big plus.  </P>
<br>
<P>But there are a lot of negatives to this game as well such as how developers did not even bother to make non-player characters to communicate naturally, how at times this game does feel like a rip off to other games that have been released, communication between the characters of the game is jarring and cringeworthy at times and how this has not been a game that has been developed to maximum fun with playing solo in mind. </P>
<br>
<P>Overall, this game is not a high point in the Alien video game franchise but decent enough to play if you are a fan of both the movie and shooter game otherwise I would avoid and play a better similar game such as Gears of War. </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>