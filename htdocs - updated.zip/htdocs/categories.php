<html DOCTYPE!>
<html>

<head>
<link rel="stylesheet" type="text/css" href="home.css"> <!--for external styling-->
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <h2>Categories</h2>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body> 

<!--Games Genre Grid -->
<br>
<div class="genre-container">
  <div class="grid-genre">
  <img src="" >
  <a href = "/action/action.php">
  <h2> Action </h2>
  </a>
  </div>
  
   <div class="grid-genre">
  <a href = "/sci-fi/Sci-fi.php">
  <h2> Sci-Fi </h2>
  </a>
  </div>
  
   <div class="grid-genre">
  <a href = "/sports/sports.php">
  <h2> Sports </h2>
  </a>
  </div>
  
  <div class="grid-genre">
  <a href = "/rpg/rpg.php">
  <h2> RPG </h2>
  </a>
  </div>
  
   <div class="grid-genre">
  <a href = "/adventure/adventure.php">
  <h2> Adventure </h2>
  </a>
  </div>
  
   <div class="grid-genre">
  <a href = "/puzzle/puzzle.php">
  <h2> Puzzle </h2>
  </a>
  </div>
  
     <div class="grid-genre">
  <a href = "/fps/fps.php">
  <h2> FPS </h2>
  </a>
  </div>
  
     <div class="grid-genre">
  <a href = "/horror/horror.php">
  <h2> Horror </h2>
  </a>
  </div>
  
  
</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>




</body>
</html>