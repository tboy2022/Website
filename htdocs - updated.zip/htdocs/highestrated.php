<html DOCTYPE!>
<html>

<head>
<link rel="stylesheet" type="text/css" href="home.css"> <!--for external styling-->
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>
  <h2>Highest Rated Games</h2>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
  
</nav>

</header>

<body>

<center>
<p id="trend_high-p">Introduction to Highest Page</p>
</center>

<br>

<center>
<p> Here are the most critically acclaimed video games and their reviews at Realist Games:</p>
</center>
<br>
<div class="game-container">

  
  <div class="grid-game"> 
  <a href = "/action/it-takes-two.php">
  <h2>It Takes Two</h2>
  <h3>Rating: 5 / 5 </h3>
  <h3>Age: 13 </h3>
  </a>
  <div class="game-desc">Gameplay of It Takes Two</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/the-king-of-fighters-xv.php">
  <h2>The King of Fighters XV </h2>
  <h3>Rating: 4.5 / 5 </h3>
  <h3>Age: 13 </h3>
  </a>
  <div class="game-desc">Gameplay of The King of Fighters XV</div>
  </div>
  
  <div class="grid-game"> 
  <a href = "/action/psychonauts-2.php">
  <h2>Psychonauts 2</h2>
  <h3>Rating: 4.5 / 5 </h3>
  <h3>Age: 7 </h3>
  </a>
  <div class="game-game">Gameplay of Psychonauts 2</div>
  </div>
  <div class="grid-game"> 
  <a href ="action/.php">
  <h2>Knockout City </h2>
  <h3>Rating: 4.5 / 5 </h3>
  <h3>Age: 10 </h3>
  </a>
  <div class="game-game">Gameplay of Knockout City</div>
  </div>
  </div>
  
<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>

</body>
</html>

