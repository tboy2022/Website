<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>The King of Fighters XV </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Action </h4><br>
  <h4>Release: 2022 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 13
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
</h4><br> 

  <h4>Age: 13 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
 The 15th! Game within the King of Fighters franchise is finally here after 2 years of Covid delays with it certainly being worth the wait. The story of this game carries on from its predecessor with a mystery being called Verse destroying the previous battle area and being defeating by winning challenges. This time it seems that a new storm is on the way to stop any tournament action from occurring. 
  </p>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/KOF.jpg" alt="King of Fighters XV">
  </div>
  
</div>

<div class="opinion">
<p>
The plot of this story does not really take the front seat for this game but multiplayer action battling with other gamers and possible moves to use against overshadow that. The game’s picture quality is top notch with the game being stunning to look at with all fighters being cel-shaded 3D models which are impressive to look at and each player has 8 different colour outfits for their costumes which prevent the players looking boring and being versatile. The background of these stages not being too bad at all to look at as well with it being obvious that gaming developers not rushing this aspect of the game. Each game feels personalized. 
</p>
<p>
This new sequel contains 39 different characters you can choose to fight in with familiar faces to fans of the franchise being in the mix. Each character will also be given to a team out of 13 potential ones. Each team contains 3 members each and once playing it is very obvious which game you are playing for. The movement of characters and animation work brilliantly as well with the battles remaining exciting to play and quick. If a computer can beat you in a battle, the option of either weakening them, strengthening yourself or both is available once you lose. This might give the needed push to move forward and 4 different types of attacks are offered here which are Light Punch, Light Kick, Hard Punch, and Hard Kick with an option of ‘Rush Mode-Auto Combo’ being offered once one form of attack is used 3 times in a row. 
</p>
<br>
<p>
The game is available to be used either locally or online with single player or multiplayer being available in both with a new type of multiplayer being introduced here called “Draft vs” which does not allow both players to use exact the same character for a battle which makes a game a lot more interesting when both cannot use exactly the same character in battle. 
</p>
<br>
<p>
Visually this game is brilliant to play and to look at. Both visual effects and stages look brilliant and really does add to the story. The game also runs smooth as butter with zero lag helping during fighting scenes which with a high frame rate helps create an incredible gaming experience with player’s moves occurring instantly. 
</p>
<br>
<p>
The biggest letdown of this game is how each character do not have an intro nor theme fighting which creates a loss for appeal. There are some annoying bugs that are notable during the games as well which can be a big nuisance and at times affect the players’ gaming experience.
</p>
<br>
<p>
This game is a lot of fun if you enjoy fighting games or the King of Fighters gaming series with it being much fun to use as well if you are inexperienced in fighting games. This is a barrel of fun in both sides of experience with chaotic moves and attacks assuming any player. This is a game that will entertain the fussiest player with ease.  
</p>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>