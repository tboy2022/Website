<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Human: Fall Flat </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Action, Adventure and Puzzle </h4><br>
  <h4>Release: </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
</h4><br> 

  <h4>Age: 3 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  This game combines the best aspects of all action, adventure and puzzle games and create a solid game that gives a different vibe of fun. This game created by the developer No Brakes Game is a calm paced game that makes the player manage and control the character who is a canvas white being with zero detail through different obstacles to succeed and move forward. While the game is not the edge of seat fun throughout, it is fun enough to play with ease and controlling him will not be a burden but end up pleasant and adoring. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/human-fall-flat.png" alt="Human Fall Flat">
  </div>
  
</div>

<div class="opinion">
  <p>
  In the game, you control the white being and his limbs are so movable that the slightest pressure can make them wobble and you need those moved well enough to pass numerous puzzles to move on and it seems simpler than it actually is with different objects and buttons being difficult to control with how week his limbs are and you need to be an expert at the character to move forwards and go ahead knowing him and he is controlled. Feels a bit like controlling a drunk being which can be fun but also insanely annoying. 
  </p>
<br>
  <p>
  The game has been considered easier than it actually s with handling and maintaining onto objects feeling impossible at times. Puzzles within this game become harder and harder which surprises a user that thought it was  gonna be like stealing candy from a baby and it does take around 5 hours to finish this game with each puzzle requiring you to look around before making the wrong one the spur decision although a benefit is how there are different solutions to an issue with innovation being encouraged here. and the fun does not stop there as a player can play with another member in multiplayer which is double the fun and levitates the game, especially humour which is already here.
  </p>
<br>
  <p>
   
There is much to like here such as how it is bundles of fun both as a multiplayer or as a single person, how the puzzles are creative, challenge and broad is another brilliant point within this game but despite the player thinking and being challenged. It never becomes unbearable nor frustrating and the physics of the character is a lot of entertainment to play around with. There is also a high refresh rate here which will show your actions immediately which is superb. 
  </p>
<br>
  <p>
  Although, it isn't the perfect game with some teething issues throughout. An issue faced is how it can become jading after a while of playing alone as it is the same old and how grabbing onto something for a period of time is a bit corrupt. Visually there is not a lot to look at nor impressive graphics either as it is just 1 player and a plain white background through the game therefore does not look satisfying and feels a bit bleak to look at. 
  </p>
<br>
<p>
Human: Fall Flat is a really nice game to play for a while being it contain elements of some simplicity which one needs at times but also challenges you for the better and allows you to use your brain in a fun way which is why I feel it appeals and would entertain to all ages as the simplistic factor with solid gameplay is a good combo.
</p>
<br>


</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>

</body>
</html>