<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>It Takes Two </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre:Action and Adventure </h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
</h4><br> 

  <h4>Age: 12 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  This game has had been dubbed one of the best both action and adventure genre game adventures of all time and boy they weren’t wrong. This artistic game takes ideas and takes them to a different proportion with a player of this game needing to be expected to run from moles, spiders in the gardens, battling microphones that are similar to snakes, ice skating within a snow globe and to fly but it is so much fun and a lot more than expected which left us surprised.
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/ittakestwo.jpg" alt="It Takes Two">
  </div>
  
</div>

<div class="opinion">
  <p>
  The creators of this game Hazelight’s prior game A way out wasn’t too bad at all but this turns it up to 11 with everything about the game being almost flawless which drags you into loving the game. Whatever your mission to move forward to the next level or communicating with giant devices around this game will never be a bore and you will 100% always be entertained here. Racing slugs in multiplayer, playing the game Bop-It or climbing up is only just some of the fun potentials you have within the game wherever you are the bathroom, closet, garage etc.
  </p>
  <br>
    <p>
  The gameplay of the actual game is instantly reactive and strong with no slacking occurring here with any element being fun to control such as flying, climbing or running with the game only being multiplayer makes it even a lot more fun and no idea or scenario will be repeated twice leading to hours of fresh fun. The broadness of possibilities is insane!
  </p>
  <br>
    <p>
  This game also pays homage to other iconic games throughout such as Mario Karts or GoW. There are also 25 different minigames playable here which are all barrel laughs with a good example being good old fashioned.
  </p>
  <br>
    <p>
  Although there is also depth to this game with it being based around a messy relationship between 2 parents who are extremely close to ending it and how this impacts their little girl Rose who sees all and uses the 2 toys which the player is for a shoulder to cry for with your mission is getting everything on track, therefore, it also is an emotional game. Not all entertainment and games.
  </p>
  <br>
    <p>
  This is one of the best games we have reviewed with so much being done absolutely right here such as the writing where you are left in stitches with laughter at times then insane pain feeling over the family which each line from them feeling realistic and passionate. The more the player does, the more the parents remember why they wanted each other and belong together. The gameplay again is immersive and the design and colour scheme of this game is insane. The gameplay feels brilliant and the story is masterful pulling every heartstring thanks to the writer Dr. Hakim is an absolute legend and genius for coming up with it.  
  </p>
  <br>
  <p>
  Although, if I had to criticize 1 element - it would be how it isn’t as consistently fun as each other at different aspects and levels but always enjoyable.
  </p>
  <br>
  <p>
  This game is 100% G.O.A.T. and it is needed to be played by absolutely everyone and their dog as it is so good and charming. This appeals to absolutely everyone and games barely getting better than it!
  </p>
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>