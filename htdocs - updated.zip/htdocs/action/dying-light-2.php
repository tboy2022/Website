<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="/../index.php">Home</a>
  <a href="/../categories.php">Categories</a>
  <a href="/../trending.php">Trending Games</a>
  <a href="/../highestrated.php">Highest Rated Games</a>
  <a href="/../upcoming.php">Upcoming Games</a>
  <a href="/../aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Dying Light 2: Stay Human</h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Action </h4><br>
  <h4>Release: 2022 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star"></span>
<span class="fa fa-star"></span>
</h4><br> 

  <h4> Age:18  </h4><br>
  
  </div>
    <div class="column middle" style="background-color:#bbb;">
  <p>
  This game sequel to the original game that came out in early 2015 with a very lukewarm reception is by far a bigger, better and meaner game.  While, it has been a hot second is once this game was announced all the way back at E3 2018. Development issues staggered the game’s release date such as that the then creative director of the game left after accusations of misbehavior caught up with him. But finally in 2022 it is here although very different to the originally promised and shown game which isn't necessarily a bad thing…. 
  </p>
  </div>
  
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/dyinglight.png" alt="Dying Light 2: Stay Human">
  </div>
  
</div>

<div class="opinion">
  <p>
The game is a soft reboot of the series’ story arc with it being set in the exact set as the original although we fast-forward a decade and a half where the world is left in a primitive state. Villedor or more commonly known “The City” is used this time with its being done of the final large settlements in the world with Harran left behind. Players play the character of Aiden Caldwell in this game a “Pilgrim” who travels through the decreasing amount of settlements on a mission to find his long-lost sister. Both siblings were abused and used in experiments into a possible deadly vaccine by a doctor called Waltz and is likely that he is in hiding in Villedor. With the game story getting the player to locate him and maybe the sister which won’t be a walk in the park.  </p>
  <br>
  <p>
The plot of the story is easy to follow with it leading to a series of complications that expects the mission to becoming harder to follow. With an obstacle followed early on is  discovering that Waltz and character’s sister are more most likely to be in the downtown ‘Central Loop’ of the city. An area that is guarded which means discovering a way of passing them which gets you caught and issued into solving a complicated murder mystery which sets off a massive war between the Peacekeepers and Survivor factions. Getting to the ‘Central Loop’ is a lot more complex that it sounds which it taking longer than 10 hours of playtime.  </p>
  <br>
  <p>
There is a lot to like about this game. The game is incredibly smooth to play with there being no lag to suffer from and the playing environment being vivid and almost life-like which makes the game really engaging to play because you feel like you are the player and not playing a console. Another big selling point is how this isn't a stereotypical game which the character teaming up with villains etc.  </p>
  <br>
  <p>
The worst thing about this game is how slow and long the game can feel to play. While, it can seem positive that it lasts longer, the duration of the game can make this game feel very dull at time and you just want something over and done with. While the story is simple and at times slow to follow through. It has some unforgettable characters and moments in the story and game. Techland do a very good job at making the city feel like a detailed living environment with its own politics and concern and the choices in the storyline are delivered well with the stereotype of a good and bad choice not existing here with sacrifices made such as cooperating with bad people to get the best for the city with the adventure and outcome not being predictable.   </p>
  <br>

</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>