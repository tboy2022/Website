<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2>Nuts </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Adventure </h4><br>
  <h4>Release: 2021 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 12 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
This game is based mostly upon squirrels with the player’s character being a rookie field investigator where different resources such as GPS, a map, caravan and a camera will be used to research into the mysterious fields of Malmoth Forest. However, as a player investigates the local squirrel community a very bizarre riddle is solved. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/nuts.png" alt="Nuts">
  </div>
  
</div>

<div class="opinion">
  <p>
  Throughout the game, you will be completing different kinds of puzzles all around such as logic, timing and surveillance). The squirrels will be monitored through implementing CCTV and watching the clips afterwards at night which allows you to monitor the motion of a squirrel and where exactly they are keeping their food. This game becomes more bizarre every day in the game and there is a chance you’ll worry as their behaviour becomes worse as the player. The theory will pop into your head of is the squirrels working against us at all and why is this case important and a thing?
  </p>
  <br>
    <p>
  You will think a lot and use a lot of brainpower in this game with it taking between roughly 3 and 4 hours for you to complete and will be thinking by the end, are squirrels allies or a foe? After investigating day and night it takes time to monitor the footage and see traces but then to also link them together.
  </p>
  <br>
    <p>
  Good aspects of this game include the logistics of this game feeling quite fresh at the start as it is quite a quirky and different game to play especially what you are compared to playing. The distinct and stunning art direction of this game is brilliant and different as well with washed-out looks and mood board of colour. The fact that most of this game is based upon squirrels will appeal to animal lovers as well with a lot finding the creatures adorable which will send them to overdrive with so much involvement here. Squirrels move fast within the game as well in real-time without missing a single beat due to a high refresh rate and powerful graphics on this game 
  </p>
  <br>
    <p>
  There are a few ways in how Nuts does not deliver as a game. After a while, the niche factor fades and the freshness of it does not feel as good. This can become a very boring game as well with the concept and what is needed to be done being too boring for gamers with not a lot to do and how it is so weak as a game without much thought being implemented. And despite not being the longest game, it somehow still feels too long and creates much unconcern for the game with how diluted the game is already being an issue.
  </p>
  <br>
    <p>
  For animal lovers especially squirrels or people who just loved any puzzles to commit to. I would recommend this game but minus those niches, I would not suggest it as it can be incredibly repetitive and being to play with not a lot on.
  </p>
  <br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>