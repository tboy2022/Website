<html DOCTYPE!>
<html>
<!--THIS IS A TEMPLATE OF THE DIFFERENT GAMES OF THE GENRE-->
<!--THERE WILL BE MANY OF THESE PAGES, THIS IS THE TEMPLATE -->
<head>
<link rel="stylesheet" type="text/css" href="game.css"> <!--for external styling-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<div class="header">
<header>
  <h1>Realist Gamers</h1>

</div>

<nav class="topnav">
  <a href="index.php">Home</a>
  <a href="categories.php">Categories</a>
  <a href="trending.php">Trending Games</a>
  <a href="highestrated.php">Highest Rated Games</a>
  <a href="upcoming.php">Upcoming Games</a>
  <a href="aboutus.php">About Us</a>
</nav>


</header>
<body>

<br>
<div class="review-container">

<div class="gametitle">
  <h2> Journey To The Savage Planet  </h2>
</div>

<div class="row">
  <div class="column side" style="background-color:#aaa;">
  <h4>Genre: Adventure </h4><br>
  <h4>Release: 2020 </h4><br>
  <!-- THE RATING HERE IS 5 STARS -->
  <!-- DELETE A ROW IF YOU WANT TO TAKE A STAR OFF -->
  <h4>Rating: 
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
<span class="fa fa-star "></span>
</h4><br> 

  <h4>Age: 13 </h4><br>
  
  </div>
  <div class="column middle" style="background-color:#bbb;">
  <p>
  The story behind Journey To The Savage Planet is a "savage planet" that brings up thoughts of hostility and survival, exploring the possible death through the dangers of life on the frontiers of space. While there are murderous objects out to get you in Journey to the Savage Planet, it isn't the point of the game and only a minor gimmick rather than the main meaning. Developer of the game, Typhoon Studios centers the game on the importance of exploration while tying it with real humour and an amusing tone to give us a light and singularly focused chunk of sci-fi adventuring. 
  </p>
  </div>
  
  <div class="column side" style="background-color:#ccc;">
  <img src="images/journey.jpg" alt="Journey To The Savage Planet">
  </div>
  
</div>

<div class="opinion">
<P>The setting of the whole game is on a single planet located deep in unmonitored space. You're pushed into the space boots of an employee of Kindred Aerospace--a rinky-dink outfit that's proud and humble of its status of being rated the fourth-best interstellar exploration company, which makes you think how bad competition could actually be. Once your feet encounter the planet itself, you'll begin to see the flora, fauna, and beings across the various biomes of planet AR-Y 26 to see whether it's fit for human habitation or not with the whole climate change thing ruining Earth.</P>
<br>
<P>This game is also playable as multiplayer with a friend which enhances the game and makes combat much more fun but playing it multiplayer doesn’t affect the game itself nor storyline at all. The option of exploring together or going and exploring different places are both options. Humour is key in this game, while playing with a friend can have its moments. The game itself is without issue funny with the high amount of full-motion videos on the player’s ship. These clips show humour and parody a lot of different topics such as the video game industry and corrupt policies at big companies.</P>
<br>
<P>There is a lot to like in this light and fun game. The stupid but fun humour is actually laughable and engages the player. Exploring the planet isn't a chore neither while being full of fun and valuable things to discover. The colour scheme of this game and how neon it is appeals to the gamer while playing as well especially with an automatic response on screen with a high fresh rate.</P>
<br>
<P>A downside to the game can be how satire it is for some hardcore gamers as well with it being off-putting for some. Some apparent bugs also disappoint players as well because it ruins the experience at times and makes it hard to play it with different elements going wrong agitating people.</P>
<br>
<P>This game is clearly a very fun and light game that is needed at times when life is heavy as it is a brilliant escape and isn't a chore to play. Playing Journey To The Savage Planet can be a very relaxing experience thanks to its humour, lightness and engaging gameplay. </P>
<br>
</div>

</div>


<!-- CREDITS --> 
<div class="footer">
  <p>-Authors: Samir, Taheem, Jack & Cai-
  <br>
  -<a href="aboutus.php">Click Here </a> for About us Page-</p>
</div>


</body>
</html>